﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Models
{
    public class EmployeeSalary
    {
        public int id { get; set; }
        public int salary { get; set; }
        public DateTime date { get; set; }
        public int Emp_Id { get; set; }
        [ForeignKey("EmpoyeeId")]
        public Employee emp { get; set; }
    }
}
