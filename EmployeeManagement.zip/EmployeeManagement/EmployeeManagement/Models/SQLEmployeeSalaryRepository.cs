﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Models
{
    public class SQLEmployeeSalaryRepository: IEmployeeSalaryRepository
    {
        public AppDbContext context { get; set; }
        public SQLEmployeeSalaryRepository(AppDbContext context)
        {
            this.context = context;
        }
        public EmployeeSalary Add(EmployeeSalary employeeSalary)
        {
            context.employeeSalaries.Add(employeeSalary);
            context.SaveChanges();
            return employeeSalary;
        }
        public List<EmployeeSalary> GetSalaries(int id)
        {
            List<EmployeeSalary> ct = new List<EmployeeSalary>();
            var e = (from p in context.employeeSalaries
                     where p.emp.Id == id
                     select p);
            ct = e.ToList();
            return ct;
        }

    }
}
