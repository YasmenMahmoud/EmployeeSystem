﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EmployeeManagement.Controller
{
    public class HomeController : Microsoft.AspNetCore.Mvc.Controller
    {
        private IEmployeeRepository _employeeRepository;
        private IEmployeeSalaryRepository _employeeSalaryRepository;
       

        public HomeController(IEmployeeRepository employeeRepository, IEmployeeSalaryRepository employeeSalaryRepository)
        {
            _employeeRepository = employeeRepository;
            _employeeSalaryRepository = employeeSalaryRepository;
        }
        public ViewResult index()
        {
            var model = _employeeRepository.GetAllEmployees();
            return View(model);
        }
        public ViewResult details(int id)
        {
            Employee employee = new Employee();

            employee = _employeeRepository.GetEmployee(id);
            
            return View(employee);
        }
        [HttpGet]
        public ViewResult create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                Employee newEmployee = _employeeRepository.Add(employee);
                return RedirectToAction("details", new { id = newEmployee.Id });
            }
            else
                return View();
        }
        public IActionResult Delete(int id)
        {
            _employeeRepository.Delete(id);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult Edit(int id)
        {   
            Employee employee = _employeeRepository.GetEmployee(id);
            return View(employee);
            
        }
        [HttpPost]
        public IActionResult Edit(Employee model)
        {
            // Check if the provided data is valid, if not rerender the edit view
            if (ModelState.IsValid)
            {
                // Retrieve the employee being edited from the database
                Employee employee = _employeeRepository.GetEmployee(model.Id);
                // Update the employee object with the data in the model object
                employee.Name = model.Name;
                employee.Email = model.Email;
                employee.Address = model.Address;

                // Call update method on the repository service passing it the
                // employee object to update the data in the database table
                Employee updatedEmployee = _employeeRepository.Update(employee);

                return RedirectToAction("details", new { id = model.Id });
            }

            return View(model);
        }
        [HttpGet]
        public ViewResult AddSalary()
        {
            ViewBag.employees = _employeeRepository.GetAllEmployees();
            return View();
        }
        [HttpPost]
        public IActionResult AddSalary(EmployeeSalary employeeSalary)
        {
            Employee _emp = _employeeRepository.GetEmployee(employeeSalary.Emp_Id);
            employeeSalary.emp = _emp;
            EmployeeSalary y = _employeeSalaryRepository.Add(employeeSalary);
           
            return RedirectToAction("SalaryDetails",new { id = employeeSalary.Emp_Id });
        }
        public ViewResult SalaryDetails(int id)
        {
            List<EmployeeSalary> _employeeSalaries = new List<EmployeeSalary>();
            _employeeSalaries = _employeeSalaryRepository.GetSalaries(id);
            ViewBag.salaries = _employeeSalaries;
            return View();
        }
    }
}
